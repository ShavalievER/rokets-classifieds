(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d4fbc138._.js",
  "static/chunks/1a3f1_@heroicons_react_24_outline_esm_69a0d623._.js"
],
    source: "dynamic"
});
