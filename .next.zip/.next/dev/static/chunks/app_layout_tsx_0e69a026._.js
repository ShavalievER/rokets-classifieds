(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_5b01b794._.js",
  "static/chunks/node_modules__pnpm_94b46a49._.js",
  "static/chunks/_5fb63e90._.css"
],
    source: "dynamic"
});
