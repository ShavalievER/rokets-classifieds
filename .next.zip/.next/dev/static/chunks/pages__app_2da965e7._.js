(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/4f160_next_dist_compiled_294f10aa._.js",
  "static/chunks/4f160_next_dist_shared_lib_aace6215._.js",
  "static/chunks/4f160_next_dist_client_c75d0bfa._.js",
  "static/chunks/4f160_next_dist_24e16e42._.js",
  "static/chunks/4f160_next_app_cd1f9057.js",
  "static/chunks/[next]_entry_page-loader_ts_0c70ed7f._.js",
  "static/chunks/e300a_react-dom_37232c96._.js",
  "static/chunks/node_modules__pnpm_6c14da8e._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js"
],
    source: "entry"
});
