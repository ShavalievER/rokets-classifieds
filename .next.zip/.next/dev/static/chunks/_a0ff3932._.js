(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_baf810fa._.js",
  "static/chunks/ab84b_dist_compiled_react-dom-experimental_cjs_react-dom-client_development_647add9b.js",
  "static/chunks/4f160_next_dist_compiled_react-dom-experimental_cjs_react-dom_development_22c595b6.js",
  "static/chunks/4f160_next_dist_compiled_react-dom-experimental_bd90ad60._.js",
  "static/chunks/4f160_next_dist_compiled_react-server-dom-turbopack-experimental_5cadb070._.js",
  "static/chunks/4f160_next_dist_compiled_next-devtools_index_40a72938.js",
  "static/chunks/4f160_next_dist_compiled_d2da0213._.js",
  "static/chunks/4f160_next_dist_client_260c94e2._.js",
  "static/chunks/4f160_next_dist_4fea854d._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
