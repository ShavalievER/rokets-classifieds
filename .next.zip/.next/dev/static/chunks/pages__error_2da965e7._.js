(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/4f160_next_dist_compiled_294f10aa._.js",
  "static/chunks/4f160_next_dist_shared_lib_26160ecc._.js",
  "static/chunks/4f160_next_dist_client_c75d0bfa._.js",
  "static/chunks/4f160_next_dist_f68b0678._.js",
  "static/chunks/4f160_next_error_48c6519e.js",
  "static/chunks/[next]_entry_page-loader_ts_eb98e9ee._.js",
  "static/chunks/e300a_react-dom_37232c96._.js",
  "static/chunks/node_modules__pnpm_6c14da8e._.js",
  "static/chunks/[root-of-the-server]__092393de._.js"
],
    source: "entry"
});
