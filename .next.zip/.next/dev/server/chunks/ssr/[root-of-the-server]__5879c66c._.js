module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/app/opengraph-image--metadata.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/opengraph-image--metadata.js [app-rsc] (ecmascript)"));
}),
"[project]/app/search/[collection]/opengraph-image--metadata.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/search/[collection]/opengraph-image--metadata.js [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/error.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/error.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/search/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/search/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/search/loading.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/search/loading.tsx [app-rsc] (ecmascript)"));
}),
"[project]/lib/demo/categories.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CATEGORY_NAMES",
    ()=>CATEGORY_NAMES,
    "CATEGORY_STRUCTURE",
    ()=>CATEGORY_STRUCTURE,
    "DEMO_COLLECTIONS",
    ()=>DEMO_COLLECTIONS,
    "getAllSubcategories",
    ()=>getAllSubcategories,
    "getCategoryByHandle",
    ()=>getCategoryByHandle,
    "getCategoryName",
    ()=>getCategoryName,
    "getSubcategoryByHandle",
    ()=>getSubcategoryByHandle
]);
/**
 * Two-level category structure for classifieds
 * Based on: https://docs.google.com/spreadsheets/d/1Z8D7fMD_Nyo2BOj6Ua3PYdJI4LTFo5h5q9e3SdDogPc/edit
 */ // Helper function to create handle from name
function createHandle(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}
const CATEGORY_STRUCTURE = [
    {
        id: 'furniture',
        name: 'Furniture',
        handle: 'furniture',
        subcategories: [
            {
                id: 'sofas-couches',
                name: 'Sofas & Couches',
                handle: 'sofas-couches'
            },
            {
                id: 'armchairs',
                name: 'Armchairs',
                handle: 'armchairs'
            },
            {
                id: 'recliners',
                name: 'Recliners',
                handle: 'recliners'
            },
            {
                id: 'sofa-beds',
                name: 'Sofa Beds',
                handle: 'sofa-beds'
            },
            {
                id: 'living-room-sets',
                name: 'Living Room Sets',
                handle: 'living-room-sets'
            },
            {
                id: 'tv-stands-media-units',
                name: 'TV Stands & Media Units',
                handle: 'tv-stands-media-units'
            },
            {
                id: 'coffee-tables',
                name: 'Coffee Tables',
                handle: 'coffee-tables'
            },
            {
                id: 'side-tables',
                name: 'Side Tables',
                handle: 'side-tables'
            },
            {
                id: 'dining-tables',
                name: 'Dining Tables',
                handle: 'dining-tables'
            },
            {
                id: 'dining-chairs',
                name: 'Dining Chairs',
                handle: 'dining-chairs'
            },
            {
                id: 'dining-sets',
                name: 'Dining Sets',
                handle: 'dining-sets'
            },
            {
                id: 'beds',
                name: 'Beds',
                handle: 'beds'
            },
            {
                id: 'mattresses',
                name: 'Mattresses',
                handle: 'mattresses'
            },
            {
                id: 'bed-frames',
                name: 'Bed Frames',
                handle: 'bed-frames'
            },
            {
                id: 'wardrobes',
                name: 'Wardrobes',
                handle: 'wardrobes'
            },
            {
                id: 'dressers-chests',
                name: 'Dressers & Chests',
                handle: 'dressers-chests'
            },
            {
                id: 'nightstands',
                name: 'Nightstands',
                handle: 'nightstands'
            },
            {
                id: 'bedroom-sets',
                name: 'Bedroom Sets',
                handle: 'bedroom-sets'
            },
            {
                id: 'office-desks',
                name: 'Office Desks',
                handle: 'office-desks'
            },
            {
                id: 'office-chairs',
                name: 'Office Chairs',
                handle: 'office-chairs'
            },
            {
                id: 'bookcases-shelves',
                name: 'Bookcases & Shelves',
                handle: 'bookcases-shelves'
            },
            {
                id: 'cabinets-sideboards',
                name: 'Cabinets & Sideboards',
                handle: 'cabinets-sideboards'
            },
            {
                id: 'shoe-racks',
                name: 'Shoe Racks',
                handle: 'shoe-racks'
            },
            {
                id: 'storage-units',
                name: 'Storage Units',
                handle: 'storage-units'
            },
            {
                id: 'kids-furniture',
                name: 'Kids Furniture',
                handle: 'kids-furniture'
            },
            {
                id: 'outdoor-furniture',
                name: 'Outdoor Furniture',
                handle: 'outdoor-furniture'
            },
            {
                id: 'garden-tables-chairs',
                name: 'Garden Tables & Chairs',
                handle: 'garden-tables-chairs'
            },
            {
                id: 'balcony-furniture',
                name: 'Balcony Furniture',
                handle: 'balcony-furniture'
            },
            {
                id: 'bar-furniture',
                name: 'Bar Furniture',
                handle: 'bar-furniture'
            },
            {
                id: 'mirrors',
                name: 'Mirrors',
                handle: 'mirrors'
            }
        ]
    },
    {
        id: 'sporting-goods',
        name: 'Sporting Goods',
        handle: 'sporting-goods',
        subcategories: [
            {
                id: 'scooters-skateboards',
                name: 'Scooters & Skateboards',
                handle: 'scooters-skateboards'
            },
            {
                id: 'running-athletics',
                name: 'Running & Athletics',
                handle: 'running-athletics'
            },
            {
                id: 'swimming-water-sports',
                name: 'Swimming & Water Sports',
                handle: 'swimming-water-sports'
            },
            {
                id: 'diving-snorkeling',
                name: 'Diving & Snorkeling',
                handle: 'diving-snorkeling'
            },
            {
                id: 'surfing-paddleboarding',
                name: 'Surfing & Paddleboarding',
                handle: 'surfing-paddleboarding'
            },
            {
                id: 'fishing',
                name: 'Fishing',
                handle: 'fishing'
            },
            {
                id: 'hunting-archery',
                name: 'Hunting & Archery',
                handle: 'hunting-archery'
            },
            {
                id: 'outdoor-camping',
                name: 'Outdoor & Camping',
                handle: 'outdoor-camping'
            },
            {
                id: 'hiking-trekking',
                name: 'Hiking & Trekking',
                handle: 'hiking-trekking'
            },
            {
                id: 'climbing-mountaineering',
                name: 'Climbing & Mountaineering',
                handle: 'climbing-mountaineering'
            },
            {
                id: 'winter-sports',
                name: 'Winter Sports',
                handle: 'winter-sports'
            },
            {
                id: 'skiing',
                name: 'Skiing',
                handle: 'skiing'
            },
            {
                id: 'snowboarding',
                name: 'Snowboarding',
                handle: 'snowboarding'
            },
            {
                id: 'golf-equipment',
                name: 'Golf Equipment',
                handle: 'golf-equipment'
            },
            {
                id: 'equestrian-sports',
                name: 'Equestrian Sports',
                handle: 'equestrian-sports'
            },
            {
                id: 'motorsports-gear',
                name: 'Motorsports Gear',
                handle: 'motorsports-gear'
            },
            {
                id: 'accessories-protection',
                name: 'Accessories & Protection',
                handle: 'accessories-protection'
            },
            {
                id: 'sports-bags',
                name: 'Sports Bags',
                handle: 'sports-bags'
            },
            {
                id: 'sports-nutrition',
                name: 'Sports Nutrition',
                handle: 'sports-nutrition'
            },
            {
                id: 'recovery-physiotherapy',
                name: 'Recovery & Physiotherapy',
                handle: 'recovery-physiotherapy'
            },
            {
                id: 'kids-sports-equipment',
                name: 'Kids Sports Equipment',
                handle: 'kids-sports-equipment'
            },
            {
                id: 'refurbished-used-equipment',
                name: 'Refurbished / Used Equipment',
                handle: 'refurbished-used-equipment'
            },
            {
                id: 'professional-commercial-equipment',
                name: 'Professional / Commercial Equipment',
                handle: 'professional-commercial-equipment'
            },
            {
                id: 'other-sporting-goods',
                name: 'Other Sporting Goods',
                handle: 'other-sporting-goods'
            }
        ]
    },
    {
        id: 'toys',
        name: 'Toys',
        handle: 'toys',
        subcategories: [
            {
                id: 'baby-toys-0-2-years',
                name: 'Baby Toys (0–2 years)',
                handle: 'baby-toys-0-2-years'
            },
            {
                id: 'toddler-toys-2-4-years',
                name: 'Toddler Toys (2–4 years)',
                handle: 'toddler-toys-2-4-years'
            },
            {
                id: 'preschool-toys-4-6-years',
                name: 'Preschool Toys (4–6 years)',
                handle: 'preschool-toys-4-6-years'
            },
            {
                id: 'educational-learning-toys',
                name: 'Educational & Learning Toys',
                handle: 'educational-learning-toys'
            },
            {
                id: 'montessori-toys',
                name: 'Montessori Toys',
                handle: 'montessori-toys'
            }
        ]
    },
    {
        id: 'auto-parts',
        name: 'Auto Parts',
        handle: 'auto-parts',
        subcategories: [
            {
                id: 'engine-parts',
                name: 'Engine Parts',
                handle: 'engine-parts'
            },
            {
                id: 'body-parts',
                name: 'Body Parts',
                handle: 'body-parts'
            },
            {
                id: 'interior-parts',
                name: 'Interior Parts',
                handle: 'interior-parts'
            },
            {
                id: 'tires-wheels',
                name: 'Tires & Wheels',
                handle: 'tires-wheels'
            },
            {
                id: 'electronics-parts',
                name: 'Electronics & Parts',
                handle: 'electronics-parts'
            },
            {
                id: 'accessories',
                name: 'Accessories',
                handle: 'accessories'
            }
        ]
    },
    {
        id: 'babies',
        name: 'Babies',
        handle: 'babies',
        subcategories: [
            {
                id: 'baby-clothing',
                name: 'Baby Clothing',
                handle: 'baby-clothing'
            },
            {
                id: 'baby-gear',
                name: 'Baby Gear',
                handle: 'baby-gear'
            },
            {
                id: 'nursery-furniture',
                name: 'Nursery Furniture',
                handle: 'nursery-furniture'
            },
            {
                id: 'feeding',
                name: 'Feeding',
                handle: 'feeding'
            },
            {
                id: 'strollers-carriers',
                name: 'Strollers & Carriers',
                handle: 'strollers-carriers'
            },
            {
                id: 'baby-safety',
                name: 'Baby Safety',
                handle: 'baby-safety'
            }
        ]
    },
    {
        id: 'clothing',
        name: 'Clothing',
        handle: 'clothing',
        subcategories: [
            {
                id: 'mens-clothing',
                name: "Men's Clothing",
                handle: 'mens-clothing'
            },
            {
                id: 'womens-clothing',
                name: "Women's Clothing",
                handle: 'womens-clothing'
            },
            {
                id: 'kids-clothing',
                name: "Kids' Clothing",
                handle: 'kids-clothing'
            },
            {
                id: 'shoes',
                name: 'Shoes',
                handle: 'shoes'
            },
            {
                id: 'accessories',
                name: 'Accessories',
                handle: 'accessories'
            },
            {
                id: 'bags-luggage',
                name: 'Bags & Luggage',
                handle: 'bags-luggage'
            }
        ]
    },
    {
        id: 'electronics',
        name: 'Electronics',
        handle: 'electronics',
        subcategories: [
            {
                id: 'mobile-phones',
                name: 'Mobile Phones',
                handle: 'mobile-phones'
            },
            {
                id: 'computers',
                name: 'Computers & Tablets',
                handle: 'computers'
            },
            {
                id: 'tv-video',
                name: 'TV, Audio & Video',
                handle: 'tv-video'
            },
            {
                id: 'cameras',
                name: 'Cameras',
                handle: 'cameras'
            },
            {
                id: 'gaming',
                name: 'Gaming',
                handle: 'gaming'
            },
            {
                id: 'audio',
                name: 'Audio Equipment',
                handle: 'audio'
            }
        ]
    },
    {
        id: 'home-garden',
        name: 'Home & Garden',
        handle: 'home-garden',
        subcategories: [
            {
                id: 'home-decor',
                name: 'Home Decor',
                handle: 'home-decor'
            },
            {
                id: 'kitchen-dining',
                name: 'Kitchen & Dining',
                handle: 'kitchen-dining'
            },
            {
                id: 'bedding-bath',
                name: 'Bedding & Bath',
                handle: 'bedding-bath'
            },
            {
                id: 'garden-tools',
                name: 'Garden Tools',
                handle: 'garden-tools'
            },
            {
                id: 'outdoor-living',
                name: 'Outdoor Living',
                handle: 'outdoor-living'
            },
            {
                id: 'home-improvement',
                name: 'Home Improvement',
                handle: 'home-improvement'
            }
        ]
    },
    {
        id: 'fashion-beauty',
        name: 'Fashion & Beauty',
        handle: 'fashion-beauty',
        subcategories: [
            {
                id: 'cosmetics',
                name: 'Cosmetics',
                handle: 'cosmetics'
            },
            {
                id: 'skincare',
                name: 'Skincare',
                handle: 'skincare'
            },
            {
                id: 'fragrances',
                name: 'Fragrances',
                handle: 'fragrances'
            },
            {
                id: 'hair-care',
                name: 'Hair Care',
                handle: 'hair-care'
            },
            {
                id: 'jewelry',
                name: 'Jewelry',
                handle: 'jewelry'
            },
            {
                id: 'watches',
                name: 'Watches',
                handle: 'watches'
            }
        ]
    }
];
const CATEGORY_NAMES = {};
// Populate CATEGORY_NAMES from CATEGORY_STRUCTURE
CATEGORY_STRUCTURE.forEach((category)=>{
    CATEGORY_NAMES[category.handle] = category.name;
    category.subcategories?.forEach((sub)=>{
        CATEGORY_NAMES[sub.handle] = sub.name;
    });
});
const DEMO_COLLECTIONS = CATEGORY_STRUCTURE.flatMap((category)=>{
    const collections = [];
    // Add main category
    collections.push({
        handle: category.handle,
        title: category.name,
        description: `${category.name} category`,
        seo: {
            title: category.name,
            description: `${category.name} category`
        },
        path: `/search/${category.handle}`,
        updatedAt: new Date().toISOString()
    });
    // Add subcategories
    if (category.subcategories) {
        category.subcategories.forEach((sub)=>{
            collections.push({
                handle: sub.handle,
                title: sub.name,
                description: `${sub.name} in ${category.name}`,
                seo: {
                    title: sub.name,
                    description: `${sub.name} in ${category.name}`
                },
                path: `/search/${category.handle}/${sub.handle}`,
                updatedAt: new Date().toISOString()
            });
        });
    }
    return collections;
});
function getCategoryName(handle) {
    return CATEGORY_NAMES[handle] || handle;
}
function getCategoryByHandle(handle) {
    return CATEGORY_STRUCTURE.find((cat)=>cat.handle === handle);
}
function getSubcategoryByHandle(categoryHandle, subcategoryHandle) {
    const category = getCategoryByHandle(categoryHandle);
    return category?.subcategories?.find((sub)=>sub.handle === subcategoryHandle);
}
function getAllSubcategories() {
    return CATEGORY_STRUCTURE.flatMap((category)=>(category.subcategories || []).map((sub)=>({
                ...sub,
                parentHandle: category.handle
            })));
}
}),
"[project]/components/classified/product-card.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/classified/product-card.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/classified/product-card.tsx <module evaluation>", "default");
}),
"[project]/components/classified/product-card.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/classified/product-card.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/classified/product-card.tsx", "default");
}),
"[project]/components/classified/product-card.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$classified$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/classified/product-card.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$classified$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/classified/product-card.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$classified$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/layout/product-grid-items.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductGridItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$grid$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/grid/index.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$classified$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/classified/product-card.tsx [app-rsc] (ecmascript)");
;
;
;
function ProductGridItems({ products }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children: products.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$grid$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].Item, {
                className: "animate-fadeIn",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$classified$2f$product$2d$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    product: product
                }, void 0, false, {
                    fileName: "[project]/components/layout/product-grid-items.tsx",
                    lineNumber: 10,
                    columnNumber: 11
                }, this)
            }, product.handle, false, {
                fileName: "[project]/components/layout/product-grid-items.tsx",
                lineNumber: 9,
                columnNumber: 9
            }, this))
    }, void 0, false);
}
}),
"[project]/components/layout/search/filters.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/layout/search/filters.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/layout/search/filters.tsx <module evaluation>", "default");
}),
"[project]/components/layout/search/filters.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/layout/search/filters.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/layout/search/filters.tsx", "default");
}),
"[project]/components/layout/search/filters.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$search$2f$filters$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/layout/search/filters.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$search$2f$filters$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/layout/search/filters.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$search$2f$filters$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/app/search/[collection]/[[...subcategory]]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CategoryPage,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$shopify$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/shopify/index.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$demo$2f$categories$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/demo/categories.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$grid$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/grid/index.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$product$2d$grid$2d$items$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/product-grid-items.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$search$2f$filters$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/search/filters.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/constants.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
async function generateMetadata(props) {
    const params = await props.params;
    const collection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$shopify$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCollection"])(params.collection);
    const subcategoryHandle = params.subcategory?.[0];
    if (!collection) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    let title = collection.seo?.title || collection.title;
    let description = collection.seo?.description || collection.description;
    if (subcategoryHandle) {
        const category = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$demo$2f$categories$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCategoryByHandle"])(params.collection);
        const subcategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$demo$2f$categories$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSubcategoryByHandle"])(params.collection, subcategoryHandle);
        if (subcategory) {
            title = subcategory.name;
            description = `${subcategory.name} in ${category?.name || ''}`;
        }
    }
    return {
        title,
        description: description || `${title} listings`
    };
}
const ITEMS_PER_PAGE = 24;
async function CategoryPage(props) {
    const searchParams = await props.searchParams;
    const params = await props.params;
    const subcategoryHandle = params.subcategory?.[0];
    const { sort, subcategory: filterSubcategory, minPrice, maxPrice, keywords, location, page } = searchParams;
    const { sortKey, reverse } = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["sorting"].find((item)=>item.slug === sort) || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["defaultSort"];
    // Get current page (default to 1)
    const currentPage = page ? parseInt(page, 10) : 1;
    const validPage = currentPage > 0 && !isNaN(currentPage) ? currentPage : 1;
    // Determine collection handle (subcategory takes priority)
    const collectionHandle = subcategoryHandle || params.collection;
    // Get all products with filters
    const allProducts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$shopify$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCollectionProducts"])({
        collection: collectionHandle,
        sortKey,
        reverse,
        filters: {
            subcategory: filterSubcategory,
            minPrice,
            maxPrice,
            keywords,
            location
        }
    });
    // Calculate pagination
    const totalItems = allProducts.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / ITEMS_PER_PAGE));
    const finalPage = Math.min(Math.max(1, validPage), totalPages);
    const startIndex = (finalPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedProducts = allProducts.slice(startIndex, endIndex);
    const category = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$demo$2f$categories$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCategoryByHandle"])(params.collection);
    const subcategory = subcategoryHandle ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$demo$2f$categories$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSubcategoryByHandle"])(params.collection, subcategoryHandle) : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-3xl font-bold text-neutral-900 dark:text-white",
                        children: subcategory ? subcategory.name : category?.name || 'Category'
                    }, void 0, false, {
                        fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                        lineNumber: 93,
                        columnNumber: 9
                    }, this),
                    subcategory && category && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 text-sm text-neutral-600 dark:text-neutral-400",
                        children: [
                            category.name,
                            " > ",
                            subcategory.name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                        lineNumber: 97,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-sm text-neutral-500 dark:text-neutral-400",
                        children: [
                            totalItems,
                            " ",
                            totalItems === 1 ? 'listing' : 'listings',
                            " found"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$search$2f$filters$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            products.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "py-12 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg text-neutral-600 dark:text-neutral-400",
                        children: "No listings found"
                    }, void 0, false, {
                        fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                        lineNumber: 112,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-sm text-neutral-500 dark:text-neutral-500",
                        children: "Try adjusting your filters or browse other categories"
                    }, void 0, false, {
                        fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                        lineNumber: 113,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                lineNumber: 111,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$grid$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                className: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$6$2e$0$2d$canary$2e$60_react_60c2d962eb59e8fdc3ce5782532c32a4$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$product$2d$grid$2d$items$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    products: products
                }, void 0, false, {
                    fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                    lineNumber: 119,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
                lineNumber: 118,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/search/[collection]/[[...subcategory]]/page.tsx",
        lineNumber: 90,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/search/[collection]/[[...subcategory]]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/search/[collection]/[[...subcategory]]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5879c66c._.js.map