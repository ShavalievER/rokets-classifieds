module.exports = [
"[project]/.next-internal/server/app/api/account/addresses/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_account_addresses_route_actions_a32f0e4b.js.map