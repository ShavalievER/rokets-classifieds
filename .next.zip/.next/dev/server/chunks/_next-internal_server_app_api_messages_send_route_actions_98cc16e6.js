module.exports = [
"[project]/.next-internal/server/app/api/messages/send/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_messages_send_route_actions_98cc16e6.js.map