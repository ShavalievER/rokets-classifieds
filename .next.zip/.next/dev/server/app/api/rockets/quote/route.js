var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rockets/quote/route.js")
R.c("server/chunks/4f160_next_ed0c11de._.js")
R.c("server/chunks/[root-of-the-server]__b2a19b50._.js")
R.c("server/chunks/_next-internal_server_app_api_rockets_quote_route_actions_223d35f9.js")
R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/rockets/quote/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/rockets/quote/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
