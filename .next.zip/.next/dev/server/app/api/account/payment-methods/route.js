var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/payment-methods/route.js")
R.c("server/chunks/4f160_next_dc06ec7c._.js")
R.c("server/chunks/[root-of-the-server]__a89fb2a9._.js")
R.c("server/chunks/_next-internal_server_app_api_account_payment-methods_route_actions_9fa54d7c.js")
R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/account/payment-methods/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/account/payment-methods/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
