var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/addresses/route.js")
R.c("server/chunks/4f160_next_6dd201a8._.js")
R.c("server/chunks/[root-of-the-server]__151fe947._.js")
R.c("server/chunks/_next-internal_server_app_api_account_addresses_route_actions_a32f0e4b.js")
R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/account/addresses/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/account/addresses/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
