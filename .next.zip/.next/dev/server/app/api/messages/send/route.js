var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/messages/send/route.js")
R.c("server/chunks/4f160_next_10b5263a._.js")
R.c("server/chunks/[root-of-the-server]__5124c6f4._.js")
R.c("server/chunks/_next-internal_server_app_api_messages_send_route_actions_98cc16e6.js")
R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/messages/send/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.6.0-canary.60_react_60c2d962eb59e8fdc3ce5782532c32a4/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/messages/send/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
