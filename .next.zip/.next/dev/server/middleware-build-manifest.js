globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/4f160_next_dist_compiled_294f10aa._.js",
      "static/chunks/4f160_next_dist_shared_lib_aace6215._.js",
      "static/chunks/4f160_next_dist_client_c75d0bfa._.js",
      "static/chunks/4f160_next_dist_24e16e42._.js",
      "static/chunks/4f160_next_app_cd1f9057.js",
      "static/chunks/[next]_entry_page-loader_ts_0c70ed7f._.js",
      "static/chunks/e300a_react-dom_37232c96._.js",
      "static/chunks/node_modules__pnpm_6c14da8e._.js",
      "static/chunks/[root-of-the-server]__45f039c3._.js",
      "static/chunks/pages__app_2da965e7._.js",
      "static/chunks/turbopack-pages__app_99683f99._.js"
    ],
    "/_error": [
      "static/chunks/4f160_next_dist_compiled_294f10aa._.js",
      "static/chunks/4f160_next_dist_shared_lib_26160ecc._.js",
      "static/chunks/4f160_next_dist_client_c75d0bfa._.js",
      "static/chunks/4f160_next_dist_f68b0678._.js",
      "static/chunks/4f160_next_error_48c6519e.js",
      "static/chunks/[next]_entry_page-loader_ts_eb98e9ee._.js",
      "static/chunks/e300a_react-dom_37232c96._.js",
      "static/chunks/node_modules__pnpm_6c14da8e._.js",
      "static/chunks/[root-of-the-server]__092393de._.js",
      "static/chunks/pages__error_2da965e7._.js",
      "static/chunks/turbopack-pages__error_5e2fb83e._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/4f160_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_baf810fa._.js",
    "static/chunks/ab84b_dist_compiled_react-dom-experimental_cjs_react-dom-client_development_647add9b.js",
    "static/chunks/4f160_next_dist_compiled_react-dom-experimental_cjs_react-dom_development_22c595b6.js",
    "static/chunks/4f160_next_dist_compiled_react-dom-experimental_bd90ad60._.js",
    "static/chunks/4f160_next_dist_compiled_react-server-dom-turbopack-experimental_5cadb070._.js",
    "static/chunks/4f160_next_dist_compiled_next-devtools_index_40a72938.js",
    "static/chunks/4f160_next_dist_compiled_d2da0213._.js",
    "static/chunks/4f160_next_dist_client_260c94e2._.js",
    "static/chunks/4f160_next_dist_4fea854d._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_2a15b303._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];