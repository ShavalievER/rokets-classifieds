var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__807ba5e1._.js")
R.c("server/chunks/4f160_next_dist_esm_build_templates_app-route_d20a6a8e.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_353150a5.js")
R.m(18260)
module.exports=R.m(18260).exports
