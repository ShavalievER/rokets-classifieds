var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rockets/quote/route.js")
R.c("server/chunks/[root-of-the-server]__834f7d4f._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/_next-internal_server_app_api_rockets_quote_route_actions_223d35f9.js")
R.m(90321)
module.exports=R.m(90321).exports
