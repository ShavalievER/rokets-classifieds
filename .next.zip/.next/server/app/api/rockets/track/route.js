var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rockets/track/route.js")
R.c("server/chunks/[root-of-the-server]__f7c37944._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/_next-internal_server_app_api_rockets_track_route_actions_97cf787c.js")
R.m(82339)
module.exports=R.m(82339).exports
