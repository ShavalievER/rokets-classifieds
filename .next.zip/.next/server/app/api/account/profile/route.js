var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/profile/route.js")
R.c("server/chunks/[root-of-the-server]__2dba8065._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/_next-internal_server_app_api_account_profile_route_actions_35f5d0f4.js")
R.m(81041)
module.exports=R.m(81041).exports
