var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/addresses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__424924d9._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/_next-internal_server_app_api_account_addresses_[id]_route_actions_5d546b2b.js")
R.m(15041)
module.exports=R.m(15041).exports
