var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/addresses/[id]/default/route.js")
R.c("server/chunks/[root-of-the-server]__ac4e2766._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/ce889_server_app_api_account_addresses_[id]_default_route_actions_991fb04e.js")
R.m(89889)
module.exports=R.m(89889).exports
