var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/payment-methods/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__06c11ce2._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/ce889_server_app_api_account_payment-methods_[id]_route_actions_96b30dda.js")
R.m(72053)
module.exports=R.m(72053).exports
