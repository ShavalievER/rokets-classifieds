var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/messages/send/route.js")
R.c("server/chunks/[root-of-the-server]__0a389635._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/_next-internal_server_app_api_messages_send_route_actions_98cc16e6.js")
R.m(34046)
module.exports=R.m(34046).exports
