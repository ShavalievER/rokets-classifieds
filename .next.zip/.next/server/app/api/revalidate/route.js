var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/revalidate/route.js")
R.c("server/chunks/[root-of-the-server]__6dbd1364._.js")
R.c("server/chunks/4f160_next_5ce2de43._.js")
R.c("server/chunks/[root-of-the-server]__f3e619bb._.js")
R.c("server/chunks/_dbe05918._.js")
R.c("server/chunks/4f160_next_dist_29ac7610._.js")
R.c("server/chunks/_next-internal_server_app_api_revalidate_route_actions_415b884f.js")
R.m(46706)
module.exports=R.m(46706).exports
