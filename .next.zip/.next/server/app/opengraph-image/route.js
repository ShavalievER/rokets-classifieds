var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[root-of-the-server]__ea3eb804._.js")
R.c("server/chunks/[root-of-the-server]__833b0586._.js")
R.c("server/chunks/4f160_next_dist_39298606._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_route_actions_ca3aeb2a.js")
R.m(29119)
module.exports=R.m(29119).exports
